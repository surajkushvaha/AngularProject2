import { ThirukkuralClass } from './thirukkural-class';

describe('ThirukkuralClass', () => {
  it('should create an instance', () => {
    expect(new ThirukkuralClass()).toBeTruthy();
  });
});
